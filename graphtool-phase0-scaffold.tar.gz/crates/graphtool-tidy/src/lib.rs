//! Data import and tidyverse-style data preparation for GraphTool.
//!
//! Phase 0 skeleton. The concrete function catalogue (cleaning, mutating,
//! filtering, grouping, reshaping) is TO BE DEFINED LATER; the output
//! contract is fixed: a tidy table.
//!
//! Tidy table contract: one observation per row, one variable per column,
//! one type per column.
//!
//! NOTE (Phase 0, sandbox build): serde derives are temporarily removed so the
//! skeleton compiles in a C-toolchain-less sandbox; re-add
//! `serde = { version = "1", features = ["derive"] }` and the derives /
//! `#[serde(...)]` attributes on the first full toolchain build, per the
//! confirmed architecture (serialisable, versioned ChartSpec).


/// Column type of a tidy table.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ColumnType {
    /// Numeric (double precision, SI-consistent units).
    Number,
    /// Categorical (factor-like).
    Text,
    /// Temporal (date, time or date-time).
    DateTime,
}

/// A tidy table: the output contract of every data import and tidying step.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct TidyTable {
    /// Column names, in order.
    pub columns: Vec<Column>,
    /// Rows, each one observation, values in column order.
    pub rows: Vec<Vec<Value>>,
}

/// A named, typed column.
#[derive(Clone, Debug, PartialEq)]
pub struct Column {
    pub name: String,
    pub ty: ColumnType,
    /// Optional description and unit shown in the Data step.
    pub desc: Option<String>,
    pub unit: Option<String>,
}

/// A cell value.
#[derive(Clone, Debug, PartialEq)]
pub enum Value {
    Number(f64),
    Text(String),
    DateTime(String),
    Missing,
}

/// One step of a tidy recipe. The operation catalogue is TO BE DEFINED LATER;
/// the variant is kept opaque (a tagged string) until then.
#[derive(Clone, Debug, PartialEq)]
pub struct TidyOp {
    pub op: String,
    pub params: Option<String>,
}

/// Apply a tidy recipe to a table. Phase 0 stub: returns the input unchanged.
pub fn apply_recipe(table: &TidyTable, _recipe: &[TidyOp]) -> TidyTable {
    table.clone()
}
