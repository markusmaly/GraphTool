//! GraphTool: grammar-of-graphics data visualisation on decks.
//!
//! Phase 0 skeleton: crate wiring and a smoke-test entry point.
//! The menu structure (Phase 1) will be registered through the command
//! framework; this binary currently verifies that all GraphTool crates
//! build and link.

use graphtool_area::{place, Placement, Rect};
use graphtool_grammar::{ChartSpec, Geom, LayerSpec};
use graphtool_presets::{Palette, PaletteKind, Preset, ThemeRef};
use graphtool_render::render;

fn main() {
    let spec = ChartSpec {
        layers: vec![LayerSpec { geom: Geom::Point, ..Default::default() }],
        ..Default::default()
    };
    let preset = Preset {
        id: "factory/grey".into(),
        name: "Grey (theme_grey)".into(),
        palette: Palette {
            id: "colorbrew/set2".into(),
            colors: vec!["#4e79a7".into(), "#f28e2b".into(), "#e15759".into()],
            kind: PaletteKind::Qualitative,
        },
        theme: ThemeRef { id: "theme_grey".into(), overrides: None },
        base_font: None,
        master_stored: false,
    };
    let drawing = render(&spec, &preset, 320.0, 180.0);
    let area = place(Rect { x: 0.0, y: 0.0, w: 720.0, h: 405.0 }, Placement::Full);
    println!(
        "GraphTool Phase 0 skeleton ok — drawing {}×{} pt with {} primitives; full area {}×{} pt",
        drawing.width_pt, drawing.height_pt, drawing.primitives.len(), area.w, area.h
    );
}
