//! GraphTool: grammar-of-graphics data visualisation on decks.
//!
//! Phase 1: the menu structure as stub commands. This binary prints the
//! seven-menu structure with all registered commands and demonstrates the
//! workflow-based enabling on a sample document. No command has an action
//! yet; later phases wire the handlers one by one.

mod command;
mod document;

use command::{invoke, menu_tree, registry, Outcome};
use document::Document;
use graphtool_area::{place, Placement, Rect};
use graphtool_grammar::ChartSpec;
use graphtool_presets::{Palette, PaletteKind, Preset, ThemeRef};
use graphtool_render::render;

fn main() {
    println!("GraphTool Phase 1 - menu structure as stub commands");
    println!();

    // Phase 1 deliverable: the complete, fixed menu tree with stub commands.
    print!("{}", menu_tree());

    let reg = registry();
    println!("{} commands registered across {} menus (all handlers: stubs)",
        reg.len(), command::MENUS.len());
    println!();

    // Workflow-based enabling, demonstrated on an empty document
    // (no slides, no graph selected) and on a document with one chart.
    let mut empty = Document::default();
    let disabled = reg.iter()
        .filter(|c| invoke(c, &mut empty) == Outcome::Disabled)
        .count();
    println!("Empty document: {} of {} commands disabled (requirement: later",
        disabled, reg.len());
    println!("workflow steps are disabled until their prerequisites are met).");

    let mut doc = Document {
        charts: vec![ChartSpec::default()],
        slide_count: 1,
        undo: Vec::new(),
    };
    let ready = reg.iter()
        .filter(|c| invoke(c, &mut doc) == Outcome::NotImplemented)
        .count();
    println!("Document with one graph: {} commands enabled as stubs \
        (selecting any item performs no action yet).", ready);
    println!();

    // Phase 0 smoke test retained: renderer stub and area negotiation.
    let preset = Preset {
        id: "factory/grey".into(),
        name: "Grey (theme_grey)".into(),
        palette: Palette {
            id: "colorbrew/set2".into(),
            colors: vec!["#4e79a7".into(), "#f28e2b".into(), "#e15759".into()],
            kind: PaletteKind::Qualitative,
        },
        theme: ThemeRef { id: "theme_grey".into(), overrides: None },
        base_font: None,
        master_stored: false,
    };
    let drawing = render(&ChartSpec::default(), &preset, 320.0, 180.0);
    let area = place(Rect { x: 0.0, y: 0.0, w: 720.0, h: 405.0 }, Placement::Full);
    println!("Renderer stub ok ({} primitives); full-slide area {}x{} pt.",
        drawing.primitives.len(), area.w, area.h);
}
